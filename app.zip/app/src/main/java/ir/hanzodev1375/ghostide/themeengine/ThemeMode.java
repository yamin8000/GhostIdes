package ir.hanzodev1375.ghostide.themeengine;

public final class ThemeMode {
  public static final int AUTO = 0;
  public static final int LIGHT = 1;
  public static final int DARK = 2;

  private ThemeMode() {}
}
